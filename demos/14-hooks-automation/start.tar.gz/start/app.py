def greet(name):
    return f"Hallo, {name}!"

def add(a, b):
    return a + b

if __name__ == "__main__":
    print(greet("Git-Schulung"))
