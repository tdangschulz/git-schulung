main: Projekt gestartet
