#!/bin/bash
# Installiert die Git-Hooks für dieses Repository
# Setzt core.hooksPath auf .githooks/

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HOOKS_DIR="$SCRIPT_DIR/.githooks"

if [ ! -d "$HOOKS_DIR" ]; then
    echo "❌ Fehler: .githooks/ nicht gefunden"
    echo "  Bist du im Repository-Root?"
    exit 1
fi

git config core.hooksPath "$HOOKS_DIR"
echo "✅ Git-Hooks aktiviert!"
echo "  Pfad: $HOOKS_DIR"
echo ""
echo "Aktive Hooks:"
for hook in pre-commit commit-msg pre-push post-commit post-merge; do
    if [ -x "$HOOKS_DIR/$hook" ]; then
        echo "  ✓ $hook"
    fi
done
echo ""
echo "Jetzt werden bei jedem Commit/Push automatisch Prüfungen ausgeführt."
echo "Mit --no-verify (git commit --no-verify) kannst du Hooks umgehen."
