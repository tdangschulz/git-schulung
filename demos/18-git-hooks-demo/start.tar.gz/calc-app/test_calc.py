#!/usr/bin/env python3
"""Unit-Tests für den Taschenrechner."""
from calc import add, subtract, multiply, divide

def test_add():
    assert add(2, 3) == 5
    assert add(-1, 1) == 0
    print("  ✓ add")

def test_subtract():
    assert subtract(10, 4) == 6
    assert subtract(0, 5) == -5
    print("  ✓ subtract")

def test_multiply():
    assert multiply(3, 4) == 12
    assert multiply(-2, 5) == -10
    print("  ✓ multiply")

def test_divide():
    assert divide(15, 3) == 5
    assert divide(7, 2) == 3.5
    print("  ✓ divide")

def test_divide_by_zero():
    try:
        divide(1, 0)
        assert False, "Sollte Exception werfen"
    except ValueError:
        pass
    print("  ✓ divide_by_zero")

if __name__ == "__main__":
    print("Tests werden ausgeführt...")
    test_add()
    test_subtract()
    test_multiply()
    test_divide()
    test_divide_by_zero()
    print("\n✅ Alle Tests bestanden!")
