#!/usr/bin/env python3
"""Git-Bisect-Test: Prueft Steuerberechnung.
Exit 0 = gut (Bug nicht vorhanden)
Exit 1 = schlecht (Bug vorhanden)
Exit 125 = Commit ueberspringen (alte API)"""
import sys
sys.path.insert(0, '.')
from receipt import generate_receipt

items = [{'name': 'Test', 'price': 100.00, 'qty': 1}]
try:
    result = generate_receipt(items, tax_rate=0.19, discount=0.10)
except Exception:
    sys.exit(125)  # Commit ueberspringen (alte API)

if len(result) >= 4:
    # tax ist 3. oder 4. Rueckgabewert
    tax = result[2] if len(result) == 4 else result[3]
    # Korrekt: (100-10)*0.19 = 17.10
    # Bug: 100*0.19 = 19.00
    if abs(tax - 17.10) < 0.01:
        sys.exit(0)  # Good
    else:
        sys.exit(1)  # Bad
else:
    sys.exit(125)  # Skip (alte API ohne Rabatt)
