#!/usr/bin/env python3
import time

def generate_receipt(items, tax_rate=0.19, discount=0, shipping=0):
    subtotal = sum(item["price"] * item["qty"] for item in items)
    discount_amount = subtotal * discount
    # BUG: Steuer wird vom Brutto statt Netto berechnet
    tax = subtotal * tax_rate
    total = subtotal - discount_amount + shipping + tax
    return subtotal, discount_amount, shipping, tax, total

def print_line(label, value, currency, width=50):
    dots = "." * (width - len(label) - len(f"{value:.2f}") - 3)
    print(f"{label} {dots} {value:.2f} {currency}")

def main():
    customer_id = "K-2024-0042"
    currency = "EUR"
    items = [
        {"name": "Laptop Stand", "price": 49.99, "qty": 1},
        {"name": "USB-C Hub", "price": 34.99, "qty": 2},
        {"name": "Mauspad", "price": 19.99, "qty": 1},
    ]
    subtotal, discount, shipping, tax, total = generate_receipt(items, discount=0.10, shipping=4.99)

    print(f"Kunde: {customer_id}")
    print("=" * 54)
    print("              RECHNUNG")
    print("=" * 54)
    print()
    for item in items:
        print(f"  {item['qty']}x {item['name']:<20s} {item['price']:>8.2f} {currency}")
    print()
    print("-" * 54)
    print_line("Zwischensumme", subtotal, currency)
    print_line("Rabatt (10%)", discount, currency)
    print_line("Versand", shipping, currency)
    print_line("MwSt (19%)", tax, currency)
    print("=" * 54)
    print_line("GESAMTSUMME", total, currency)
    print()
    print(f"Datum: {time.strftime('%d.%m.%Y')}")

if __name__ == "__main__":
    main()
