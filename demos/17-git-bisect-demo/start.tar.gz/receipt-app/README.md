# Rechnungs-App

Eine kleine Python-App zur Rechnungsgenerierung.
