#!/usr/bin/env python3
import sys
sys.path.insert(0, ".")
from receipt import generate_receipt

items = [{"name": "Test Item", "price": 100.00, "qty": 1}]
sub, disc, tax, total = generate_receipt(items, tax_rate=0.19, discount=0.10)

ok = True
if abs(sub - 100.00) >= 0.01:
    print(f"Fehler: Zwischensumme {sub:.2f} != 100.00")
    ok = False
if abs(disc - 10.00) >= 0.01:
    print(f"Fehler: Rabatt {disc:.2f} != 10.00")
    ok = False
expected_tax = 17.10  # (100-10) * 0.19 = 17.10
if abs(tax - expected_tax) >= 0.01:
    print(f"Fehler: Steuer {tax:.2f} != {expected_tax:.2f}")
    ok = False
expected_total = 107.10  # 100 - 10 + 17.10 = 107.10
if abs(total - expected_total) >= 0.01:
    print(f"Fehler: Summe {total:.2f} != {expected_total:.2f}")
    ok = False

if ok:
    print("Alle Tests bestanden!")
    sys.exit(0)
else:
    print("Tests FEHLGESCHLAGEN!")
    sys.exit(1)
