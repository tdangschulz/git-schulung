# Starport 42

Intergalaktische Weltraumstation — Webseite.

Dieses Repository dient als Trainingsbeispiel für Git Merge-Strategien.
