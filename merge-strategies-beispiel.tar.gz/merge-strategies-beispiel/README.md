# Starport 42 — Git Merge-Strategien 🚀

Intergalaktische Weltraumstation als Trainingsbeispiel für Git Merge-Strategien.
Enthält 7 Szenarien auf verschiedenen Branches.

## Quickstart

```bash
tar xzf merge-strategies-beispiel.tar.gz
cd merge-strategies-beispiel
git log --oneline --graph --all --decorate --abbrev-commit
# Dann ein Szenario auswählen und loslegen!
```

---

## Szenario 1: Fast-Forward Merge

**Branch: feature/station-map**

Der einfachste Merge: main hat sich seit dem Abzweig **nicht verändert**.
Git muss nur den Branch-Zeiger verschieben — kein neuer Merge-Commit.

### Theorie
```
      A---B---C feature
     /
D---E main

→ git checkout main && git merge feature

      A---B---C feature
     /         
D---E----------C main  (main zeigt jetzt auf C)
```

### Ausprobieren:
```bash
git checkout main
git merge feature/station-map
# → Fast-Forward! main zeigt jetzt auf den selben Commit
git log --oneline  # Kein Merge-Commit, nur 5 Einträge
```

**Wann passiert das?**
- Wenn main seit dem Branch keine neuen Commits hat
- Feature-Branches an denen allein gearbeitet wird
- Einfache, lineare Historie

**Achtung:** Mit `git merge --no-ff` kann man auch hier einen Merge-Commit erzwingen.

---

## Szenario 2: 3-Way Merge

**Branch: feature/contact**

Sowohl main als auch feature/contact haben **neue Commits** seit dem Abzweig.
Git erzeugt einen Merge-Commit mit 2 Eltern.

### Theorie
```
      A---B feature
     /
D---E---F main

→ git checkout main && git merge feature

      A---B feature
     /    
D---E---F---M main  (M = Merge-Commit mit 2 Eltern)
```

### Ausprobieren:
```bash
git checkout main
git merge feature/contact
# → Merge-Commit wird erstellt (Editor öffnet sich)
# → Nachricht: "Merge branch 'feature/contact'"
git log --oneline --graph
# → Sieht man den Merge-Commit mit 2 Eltern!
```

**Wann passiert das?**
- Team-Projekte: mehrere Leute arbeiten parallel
- Nach längerer Arbeit an einem Feature während main weiterlief
- Der Normalfall in der Praxis

---

## Szenario 3: Merge-Konflikt lösen

**Branch: feature/theming**

Beide Branches haben **dieselbe Datei** (`style.css`) an ähnlichen Stellen geändert.
Git weiß nicht, welche Änderung gewinnen soll → Konflikt!

### Ausprobieren:
```bash
git checkout main
git merge feature/theming
# → CONFLICT in style.css!
# → "Automatic merge failed; fix conflicts and then commit the result."

# Konflikt ansehen:
cat style.css
# Sieht aus wie:
# <<<<<<< HEAD
# footer { background: #001133; ... }
# =======
# footer { background: #331100; ... }
# >>>>>>> feature/theming

# Lösen: Beide Versionen kombinieren (oder eine wählen)
# Z.B.: footer { background: linear-gradient(...); }
# Wichtig: <<<<<<< ======= >>>>>>> Marker ENTFERNEN!

# Danach:
git add style.css
git commit
# → Merge-Commit wird erstellt
```

**Tipps für Konfliktlösung:**
- `git status` zeigt welche Dateien konfliktion
- `git diff` zeigt die Konflikte an
- `git merge --abort` bricht den Merge komplett ab
- Konflikte nur manuell lösbar — Git kann nicht raten

---

## Szenario 4: Rebase

**Branch: feature/rebase-test**

Rebase schreibt die Commits eines Branches **auf die Spitze von main** um.
Ergebnis: eine lineare Historie als wäre alles nacheinander passiert.

### Theorie
```
      A---B feature
     /
D---E---F main

→ git checkout feature && git rebase main

              A'---B' feature
             /
D---E---F main

→ A' und B' sind NEUE Commits (neue Hashes!)
```

### Ausprobieren:
```bash
git checkout feature/rebase-test
git rebase main
# → feature/rebase-test ist jetzt auf main + eigene Commits
# → Historie ist linear!
git log --oneline --graph
# → Kein Merge-Commit - sieht aus wie Fast-Forward

# Zurück zu main und mergen:
git checkout main
git merge feature/rebase-test
# → Fast-Forward, weil rebased
```

**Wann Rebase statt Merge?**
- Eigene Feature-Branches vor dem Merge aufräumen
- Saubere, lineare Historie erwünscht
- **Nicht** auf gepushten Branches die andere haben!

---

## Szenario 5: Cherry-Pick

**Branch: feature/admin-panel**

Nur **einzelne Commits** aus einem anderen Branch übernehmen,
ohne den ganzen Branch zu mergen.

### Ausprobieren:
```bash
git checkout main

# Hash vom Zugriffskontrolle-Commit finden:
git log --oneline feature/admin-panel
# → abc1234 FEAT: Zugriffskontrolle für Admin-Bereich

# Nur DIESEN Commit übernehmen:
git cherry-pick <hash-von-admin-py>
# → admin.py ist jetzt auch auf main!
git log --oneline  # Neuer Commit mit selben Änderungen
```

**Wann verwenden?**
- Bugfix aus einem anderen Branch ins Release übernehmen
- Nur bestimmte Features übernehmen, nicht den ganzen Branch
- "Hotfix" in Production ohne alles andere zu deployen

---

## Szenario 6: Octopus Merge (3+ Branches gleichzeitig!)

**Branches: feature/ticket-system, feature/crew-portal, feature/menu-leiste**

Git kann **mehrere Branches auf einmal** mergen — das ist der Octopus Merge.
Voraussetzung: **keine Konflikte** zwischen den Branches (unterschiedliche Dateien).

### Theorie
```
      A---B---C  (3 Feature-Branches)
     /   /   /
D---E main

→ git checkout main && git merge A B C

D---E---A---B---C main  (Octopus-Merge-Commit mit 4 Eltern!)
```

### Ausprobieren:
```bash
git checkout main

# ALLE drei Branches auf einmal mergen:
git merge feature/ticket-system feature/crew-portal feature/menu-leiste
# → Ein Octopus-Merge-Commit mit 4 Eltern!
git log --oneline --graph
# → siehe da: ein Commit merge-t 3 Branches!
```

**Wann verwenden?**
- Mehrere unabhängige, kleine Features gleichzeitig einspielen
- Release-Branches die mehrere Fixes bündeln
- CI/CD: wenn mehrere PRs unabhängig sind

**Einschränkungen:**
- Nur bei **konfliktfreien** Branches (unterschiedliche Dateien)
- `git merge -s octopus` ist die Standardstrategie (selten manuell nötig)
- Bei Konflikten: einzeln mergen oder `git merge -s resolve`

---

## Szenario 7: Revert (wenn was schief geht)

`git revert` macht einen Commit rückgängig, indem es einen **neuen Commit** erstellt.
Die History bleibt erhalten — sicher für gepushte Branches.

### Ausprobieren:
```bash
# Nach einem Merge oder Cherry-Pick:
git revert HEAD --no-edit
# → Neuer Commit macht die letzten Änderungen rückgängig
```

---

## Entscheidungsmatrix

| Situation | Strategie | Befehl |
|-----------|-----------|--------|
| main hat keine neuen Commits | Fast-Forward | `git merge <branch>` (automatisch) |
| main hat parallel weiterentwickelt | 3-Way Merge | `git merge <branch>` (Merge-Commit) |
| Gleiche Datei in beiden geändert | Konflikt lösen | Manuell + `git add` + `git commit` |
| History soll linear bleiben | Rebase | `git rebase main` + dann merge |
| Nur einzelne Commits übernehmen | Cherry-Pick | `git cherry-pick <hash>` |
| Mehrere Branches auf einmal (konfliktfrei) | Octopus Merge | `git merge <b1> <b2> <b3>` |
| Schon gepushten Commit rückgängig | Revert | `git revert <hash>` |

---

## Branches Übersicht

```
main ──── feature/station-map (Fast-Forward)
    \─── feature/contact (3-Way Merge)
    \─── feature/theming (Konflikt)
    \─── feature/rebase-test (Rebase)
    \─── feature/admin-panel (Cherry-Pick)
    ├─── feature/ticket-system (Octopus)
    ├─── feature/crew-portal (Octopus)
    └─── feature/menu-leiste (Octopus)
```

---

## Visualisierung der Merge-Geschichte

```bash
# Zeigt alle Branches mit ihrem Merge-Verhältnis:
git log --oneline --graph --all --decorate --abbrev-commit
```

**Legende:**
- `*` = Commit
- `|` = Parent-Linie
- `/` = Branch-Abzweig
- `\` = Merge-Rückführung
