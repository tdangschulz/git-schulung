def check_access(user):
    return user in ["captain", "first_officer"]
