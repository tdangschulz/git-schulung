# Git Interactive Rebase — Beispiel-Projekt

Zeigt alle Möglichkeiten von `git rebase -i` (interaktiver Rebase).
Enthält 7 Szenarien mit vorbereiteten Branches zum direkten Durchspielen.

## Quickstart

```bash
tar xzf rebase-interactive-beispiel.tar.gz
cd rebase-interactive-beispiel
git log --oneline --graph --all --decorate --abbrev-commit
# Branch auswählen und loslegen!
git switch szenario/squash
```

---

## Szenario 1: squash — Commits zusammenfassen

**Branch: szenario/squash**

Drei separate Dateien wurden in drei einzelnen Commits erstellt (`about.md`, `contact.md`, `imprint.md`).
Das gehört eigentlich in einen einzigen Commit "FEAT: About- und Kontaktseiten hinzugefügt".

### Ausprobieren:
```bash
git switch szenario/squash
git log --oneline
# → 3 Commits: "Add about", "Add contact", "Add imprint"
git rebase -i HEAD~3
# Editor öffnet sich mit:
# pick abc123 Add about
# pick def456 Add contact
# pick ghi789 Add imprint
#
# Alles außer dem ersten "pick" durch "squash" ersetzen:
# pick abc123 Add about
# squash def456 Add contact
# squash ghi789 Add imprint
#
# Speichern + Schließen → Editor für neue Commit-Nachricht
# "FEAT: About-, Kontakt- und Impressumsseiten hinzugefügt"
#
# Fertig! 3 Commits = 1 Commit
git log --oneline
```

**Wann verwenden?**
- "Oops, ich hab vergessen das in einen Commit zu packen"
- Review-Kommentare in der History bereinigen vor dem Push
- Feature-Branch vor dem Merge in main aufräumen

---

## Szenario 2: fixup — wie squash, aber ohne Nachricht

**Branch: szenario/fixup**

Nach dem README-Commit fiel ein Tippfehler auf ("Mein Blog" → "Mein Reiseblog").
Statt einem extra Commit "fix typo" kann das mit `fixup` in den vorherigen Commit einfließen -
die Nachricht des fixup-Commits wird verworfen.

### Ausprobieren:
```bash
git switch szenario/fixup
git log --oneline
# → "FEAT: README" + "fix typo"
git rebase -i HEAD~2
# pick abc123 FEAT: README
# pick def456 fix typo → **fixup**
# Speichern + Schließen
git log --oneline
# → Nur noch "FEAT: README" — inkl. Tippfehler-Korrektur!
```

**Wann verwenden?**
- Kleine Korrekturen die keine eigene Nachricht brauchen
- "Ach ja, und hier noch..." — Verbesserungen zum vorherigen Commit

---

## Szenario 3: reword — Commit-Nachricht ändern

**Branch: szenario/reword**

Die Commit-Nachricht enthält Tippfehler: "addd new stylez"
Statt zu revertieren und neu zu commiten einfach die Nachricht ändern.

### Ausprobieren:
```bash
git switch szenario/reword
git log --oneline  # "addd new stylez" 🤦
git rebase -i HEAD~1
# pick → **reword**
# Speichern → Editor öffnet sich
# "addd new stylez" → "FEAT: Neue Styles hinzugefügt"
git log --oneline  # Neue Nachricht!
```

**Wann verwenden?**
- Tippfehler in der Commit-Nachricht
- Nachricht war irreführend oder zu vage
- Noch **nicht** gepusht! (sonst `git commit --amend` oder push force)

---

## Szenario 4: reorder — Reihenfolge ändern

**Branch: szenario/reorder**

Die zwei Commits sind in unlogischer Reihenfolge:
1. Refactoring: Navi-Styling ausgelagert
2. Feature: Navigation mit Menü-Links

Eigentlich sollte erst das Feature kommen, dann das Refactoring.

### Ausprobieren:
```bash
git switch szenario/reorder
git log --oneline
# → REFACTOR (A) → FEAT (B) — falsche Reihenfolge!
git rebase -i HEAD~2
# Im Editor die Zeilen vertauschen:
# pick ghi789 FEAT: Navigation...  ← nach oben
# pick def456 REFACTOR: Navi-Styling...  ← nach unten
# Speichern + Schließen (Konflikt möglich! Hier nicht)
git log --oneline
# → FEAT → REFACTOR — logische Reihenfolge!
```

**Wann verwenden?**
- History soll logisch (chronologisch im Sinn, nicht zeitlich) sein
- Feature zuerst, dann Optimierungen/Refactoring

---

## Szenario 5: drop — Commit löschen

**Branch: szenario/drop**

Ein Debug-Script (`debug.js`) wurde versehentlich commitet.
Soll aus der History entfernt werden, das Feature danach (`FEAT: Blog-Post Styling`) bleibt.

### Ausprobieren:
```bash
git switch szenario/drop
git log --oneline
# → "Add debug script" + "FEAT: Blog-Post Styling"
git rebase -i HEAD~2
# pick def456 Add debug script → **drop** (oder Zeile komplett löschen)
# pick ghi789 FEAT: Blog-Post Styling → pick (lassen)
# Speichern + Schließen
git log --oneline
# → Nur noch "FEAT: Blog-Post Styling"!
ls  # debug.js ist weg!
```

**Wann verwenden?**
- Debug-Code, Test-Dateien, versehentlich committed
- Commits die nicht in den Feature-Branch gehören
- **Achtung:** Nur wenn noch nicht gepusht oder Force-Push ok!

---

## Szenario 6: edit — Commit aufsplitten

**Branch: szenario/edit**

Ein Commit enthält zwei unabhängige Änderungen (About-Seite + Projekte-Seite).
Soll in zwei separate Commits aufgeteilt werden.

### Ausprobieren:
```bash
git switch szenario/edit
git log --oneline
# → "FEAT: About und Projects in einem Commit"
git rebase -i HEAD~1
# pick → **edit**
# Speichern → Rebase pausiert bei diesem Commit
git reset HEAD~1  # Änderungen ins Arbeitsverzeichnis (ungestaged)
git status        # about.html + projects.html sind ungestaged

# Jetzt in zwei Commits aufteilen:
git add about.html
git commit -m "FEAT: About-Seite hinzugefügt"
git add projects.html
git commit -m "FEAT: Projekte-Seite hinzugefügt"

# Rebase fortsetzen:
git rebase --continue

git log --oneline
# → Zwei saubere Commits statt einem überladenen!
```

**Wann verwenden?**
- "Ich hab zu viel auf einmal committed"
- Review wird einfacher wenn Commits klein und thematisch sind
- "Atomic Commits" — ein Commit = eine logische Änderung

---

## Szenario 7: autosquash — Automatisch fixupen

**Branch: szenario/autosquash**

Nach dem Feature-Commit wurde ein Fix mit `git commit --fixup` erstellt.
Das erzeugt automatisch einen Commit mit Prefix `fixup!`.
Beim Rebase mit `--autosquash` wird der Fix automatisch an die richtige Stelle sortiert.

### Ausprobieren:
```bash
git switch szenario/autosquash
git log --oneline --graph
# → "FEAT: Footer-Styling" + "fixup! FEAT: Footer-Styling"
git rebase -i --autosquash HEAD~2
# Im Editor sieht man sofort:
# pick abc123 FEAT: Footer-Styling
# fixup def456 fixup! FEAT: Footer-Styling  ← automatisch einsortiert!
# Einfach speichern + schließen
git log --oneline
# → Nur ein Commit, der Fix ist eingeflossen!
```

**Wann verwenden?**
- "Ich hab den Fehler schon committed, aber mit --fixup"
- Ideal für Code-Review: Fehler separat committen, später zusammenführen
- Spart Zeit: kein manuelles Nachdenken "welcher fixup gehört zu welchem commit?"

---

## Kurzreferenz: rebase -i Befehle

| Befehl | Kürzel | Bedeutung |
|--------|--------|-----------|
| `pick` | `p` | Commit übernehmen (wie er ist) |
| `reword` | `r` | Commit-Nachricht ändern |
| `edit` | `e` | Commit anhalten (zum Aufsplitten/Ändern) |
| `squash` | `s` | Mit vorherigem Commit zusammenfassen (Nachrichten kombinieren) |
| `fixup` | `f` | Wie squash, aber Nachricht verwerfen |
| `exec` | `x` | Shell-Befehl ausführen |
| `break` | `b` | Anhalten (z.B. zum Testen) |
| `drop` | `d` | Commit löschen |

---

## Wichtige Regeln für Rebase

1. **Niemals rebasen auf gepushten Commits** die andere schon haben!
   → Ausnahme: Feature-Branch wo du allein dran arbeitest
2. **Rebase ≠ Merge** — Rebase schreibt History um (neue Commit-Hashes!)
3. **Konflikte** können beim Rebase auftreten → normal auflösen wie bei Merge
4. **Bei Problemen:** `git rebase --abort` macht alles rückgängig
5. **Autosquash** nur mit `git commit --fixup` oder `--squash` vorbereiten

---

## Branches Übersicht

```
main ──── szenario/squash (3 Commits → 1)
    \─── szenario/fixup (Korrektur ohne Message)
    \─── szenario/reword (Nachricht korrigieren)
    \─── szenario/reorder (Reihenfolge tauschen)
    \─── szenario/drop (Commit löschen)
    \─── szenario/edit (Commit aufsplitten)
    \─── szenario/autosquash (automatischer fixup)
```
