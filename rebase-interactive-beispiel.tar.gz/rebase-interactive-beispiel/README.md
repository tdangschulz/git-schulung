# Git Interactive Rebase — Beispiel-Projekt

Zeigt alle Möglichkeiten von `git rebase -i` (interaktiver Rebase).

## Szenarien

### 1️⃣ squash — Commits zusammenfassen
Branch: szenario/squash (3 separate Datei-Commits)
```
git rebase -i HEAD~3
# → Alle 3 "pick" durch "squash" ersetzen
# → Eine Commit-Nachricht für alle 3
```

### 2️⃣ fixup — Wie squash, aber ohne Nachricht
Branch: szenario/fixup (Tippfehler-Korrektur)
```
git rebase -i HEAD~2
# → Ersten "pick" lassen, zweiten durch "fixup" ersetzen
# → Zweite Nachricht wird verworfen
```

### 3️⃣ reword — Nachricht ändern
Branch: szenario/reword (Tippfehler in Commit-Nachricht)
```
git rebase -i HEAD~1
# → "pick" durch "reword" ersetzen
# → Editor öffnet sich mit der Nachricht
```

### 4️⃣ reorder — Reihenfolge ändern
Branch: szenario/reorder (Feature + Refactoring vertauscht)
```
git rebase -i HEAD~2
# → Zeilen im Editor vertauschen
# → Jetzt: erst Feature, dann Refactoring
```

### 5️⃣ drop — Commit löschen
Branch: szenario/drop (debug.js-Commit entfernen)
```
git rebase -i HEAD~2
# → "pick" durch "drop" ersetzen oder Zeile löschen
```

### 6️⃣ edit — Commit aufsplitten
Branch: szenario/edit (ein Commit mit 2 Dateien)
```
git rebase -i HEAD~1
# → "pick" durch "edit" ersetzen
# → git reset HEAD~1 (eine Datei pro Commit)
# → git add about.html && git commit -m "..."
# → git add projects.html && git commit -m "..."
# → git rebase --continue
```

### 7️⃣ autosquash — Automatisch fixupen
Branch: szenario/autosquash
```
git rebase -i --autosquash HEAD~2
# → fixup-commit wird automatisch an die richtige Stelle sortiert!
```
