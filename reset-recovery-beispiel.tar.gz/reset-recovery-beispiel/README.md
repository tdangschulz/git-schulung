# Git Reset & Recovery — Beispiel-Projekt

Dieses Repository demonstriert verschiedene Git-Recovery-Szenarien.
Jeder Branch enthält ein eigenes Szenario mit vorbereiteten Commits.

## Quickstart

```bash
tar xzf reset-recovery-beispiel.tar.gz
cd reset-recovery-beispiel
git log --oneline --graph --all --decorate
git switch szenario/restore
# Anleitung in den Dateien lesen oder README.md öffnen
```

---

## Szenario 1: reset --soft

**Branch: szenario/reset-soft**

`git reset --soft` macht den letzten Commit rückgängig, **behält aber alle Änderungen im Staging-Bereich** (index). Perfekt wenn man vergessen hat, eine Datei zu commiten und den Commit "nachbessern" will.

### Ausprobieren:
```bash
git switch szenario/reset-soft
git log --oneline  # Letzter Commit: "FEAT: TODO für Potenz-Funktion"
git reset --soft HEAD~1
git status         # Änderungen sind GESTAGED (grün)
git diff --cached  # Änderungen sind noch da!
# Jetzt fixen und neu commiten:
git commit -m "FEAT: Potenz-Funktion (jetzt komplett)"
```

### Wann verwenden?
- Vergessene Dateien nachträglich in den Commit packen
- Commit-Nachricht "umschreiben" (aber dann lieber `commit --amend`)
- Commit aufsplitten wollen

---

## Szenario 2: reset --mixed (Standard)

**Branch: szenario/reset-mixed**

`git reset` (ohne Flag) ist `git reset --mixed`. Der Commit wird rückgängig gemacht und die Änderungen landen **im Arbeitsverzeichnis, aber nicht im Staging**. Standardverhalten!

### Ausprobieren:
```bash
git switch szenario/reset-mixed
git log --oneline  # Letzter Commit: "DOCS: README hinzugefügt"
git reset HEAD~1
git status         # README.md ist UNGESTAGED (rot)
# Neu stagen und commiten:
git add README.md
git commit -m "DOCS: README hinzugefügt"
```

### Wann verwenden?
- Man will den Commit rückgängig machen und die Änderungen nochmal durchgehen
- Standard — meistens das was man will

---

## Szenario 3: reset --hard (Gefährlich!)

**Branch: szenario/reset-hard**

`git reset --hard` macht den Commit rückgängig **und verwirft ALLE Änderungen** komplett.
Das ist der einzige Befehl der wirklich **Daten unwiderruflich löscht** (lokal).

### Ausprobieren:
```bash
git switch szenario/reset-hard
git log --oneline
# Zwei Commits: Konfiguration + Potenz-Funktion
git reset --hard HEAD~1
git log --oneline  # BEIDE Commits weg!
git status         # nichts mehr da
```

### Rettung!
```bash
git reflog          # Zeigt ALLE Aktionen (auch gelöschte Commits!)
# Suche den verlorenen Commit, kopiere den Hash
git reset --hard <hash-aus-reflog>
git log --oneline  # Wieder da!
```

### Wann verwenden?
- **Nur** wenn der Commit lokal ist und noch nie gepusht wurde
- Experimente die man komplett verwerfen will
- **Nie** bei gepushten Commits (dann `git revert` verwenden!)

---

## Szenario 4: revert (Sicher!)

**Branch: szenario/revert**

`git revert` macht einen Commit rückgängig, indem es **einen NEUEN Commit erstellt** der die Änderungen des alten rückgängig macht.
Die History bleibt erhalten — **sicher für gepushte Branches!**

### Ausprobieren:
```bash
git switch szenario/revert
git log --oneline  # "BUG: Fakultät mit float-Fehler"
git revert HEAD --no-edit
git log --oneline  # Neuer Commit "Revert ..."
cat projekt.py     # Fehlerhafter Code ist weg
```

### Wann verwenden?
- **Immer** wenn der Commit bereits gepusht wurde
- Team-Projekte — andere haben den Commit schon
- Einfach und sicher

---

## Szenario 5: reflog Recovery

**Branch: szenario/reflog**

Der Reflog (Reference Log) ist Gits "Zeitmaschine". Er zeichnet **ALLE Aktionen** auf —
auch gelöschte Branches, zurückgesetzte Commits, etc.

### Ausprobieren:
```bash
git switch szenario/reflog

# Simuliere: Branch versehentlich löschen:
git branch -D branch-zum-loeschen

# Panik! Der Branch mit 3 wichtigen Commits ist weg!
git branch -a  # nix mehr da

# Rettung per Reflog:
git reflog
# Suche die Zeile mit dem Branch-Checkout oder dem letzten Commit
git switch -c wiederhergestellt <hash-aus-reflog>
git log --oneline  # Alle Commits wieder da!
```

### Wann verwenden?
- Branch gelöscht? → reflog
- `reset --hard` zu weit gegangen? → reflog
- Alles was "weg" ist, ist noch 90 Tage im reflog!

---

## Szenario 6: restore (unstagen + unmodify)

**Branch: szenario/restore**

`git restore` ist der moderne Ersatz für `git checkout -- <datei>`.
Getrennt für Staging und Arbeitsverzeichnis.

### Ausprobieren:
```bash
git switch szenario/restore
git status
# file1.py → gestaged (grün)
# file2.py → ungestaged (rot)

# Aus Staging nehmen (ohne Änderungen zu verlieren):
git restore --staged file1.py
git status  # file1.py jetzt auch rot

# Ungestagte Änderungen komplett verwerfen:
git restore file2.py
git status  # file2.py wieder original
```

### Wann verwenden?
- `git restore --staged datei` = `git reset HEAD datei` (aber verständlicher)
- `git restore datei` = Änderungen verwerfen (ACHTUNG: unwiderruflich!)

---

## Entscheidungsmatrix

| Situation | Befehl |
|-----------|--------|
| Lokalen Commit rückgängig, Änderungen **behalten** (gestaged) | `git reset --soft HEAD~1` |
| Lokalen Commit rückgängig, Änderungen **behalten** (ungestaged) | `git reset HEAD~1` |
| Lokalen Commit **komplett** wegwerfen | `git reset --hard HEAD~1` |
| Gepushten Commit rückgängig machen | `git revert HEAD` |
| Aus Staging nehmen | `git restore --staged datei` |
| Ungestagte Änderungen verwerfen | `git restore datei` |
| Gelöschten Branch wiederfinden | `git reflog` + `git switch -c <name> <hash>` |

---

## Branches Übersicht

```
main ──── szenario/reset-soft
    \─── szenario/reset-mixed
    \─── szenario/reset-hard
    \─── szenario/revert
    \─── szenario/reflog
    \─── szenario/restore
```

> **Tipp:** Mit `git log --oneline --graph --all --decorate` siehst du alle Branches auf einmal!
