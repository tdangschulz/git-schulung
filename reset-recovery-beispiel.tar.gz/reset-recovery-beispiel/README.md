# Git Reset & Recovery — Beispiel-Projekt

Dieses Repository demonstriert verschiedene Git-Recovery-Szenarien.

## Szenarien

### 1️⃣ reset --soft
Branch: szenario/reset-soft
- `git reset --soft HEAD~1` → Commit rückgängig, Änderungen bleiben im Staging
- `git reset --soft HEAD~1` → Änderungen bleiben im Arbeitsverzeichnis

### 2️⃣ reset --mixed (default)
Branch: szenario/reset-mixed
- `git reset HEAD~1` → Commit rückgängig, Änderungen im Arbeitsverzeichnis (nicht gestaged)

### 3️⃣ reset --hard (⚠️ Gefährlich!)
Branch: szenario/reset-hard
- `git reset --hard HEAD~1` → Commit KOMPLETT weg (lokal!)
- `git reflog` → Findet den "verlorenen" Commit wieder

### 4️⃣ revert (Sicher!)
Branch: szenario/revert
- `git revert HEAD` → Macht letzten Commit rückgängig (neuer Commit!)
- Sicher für gepushte Branches

### 5️⃣ reflog Recovery
Branch: szenario/reflog
- Branch versehentlich gelöscht? `git reflog` zeigt alles!
- `git switch -c gerettet <hash>` → Branch wiederherstellen

### 6️⃣ restore
Branch: szenario/restore
- `git restore --staged file1.py` → Aus Staging nehmen (unstagen)
- `git restore file2.py` → Ungestagte Änderungen verwerfen
