def add(a, b):
    return a + b

def multiply(a, b):
    return a * b

print("Willkommen im Taschenrechner!")
print(add(3, 4))
print(multiply(2, 5))

def subtract(a, b):
    return a - b

def divide(a, b):
    if b == 0:
        return "Fehler"
    return a / b
