# Git Hooks & Automation — Beispiel-Projekt

Zeigt wie man Git Hooks im Team verwendet und verteilt.

## Verfügbare Hooks

| Hook | Wann? | Was macht er? |
|------|-------|---------------|
| pre-commit | Vor `git commit` | Prüft Syntax + Whitespace |
| commit-msg | Beim Speichern der Nachricht | Validiert Format + Prefix |
| pre-push | Vor `git push` | Führt Tests aus |
| post-commit | Nach `git commit` | Schreibt CHANGELOG.md |
| post-merge | Nach `git merge` | Prüft dependencies |

## Installation

```bash
# Einmalig pro Entwickler:
bash scripts/install-hooks.sh
```

Die Hooks liegen in `.githooks/` (wird versioniert!) und werden per Symlink
in `.git/hooks/` installiert. So werden Updates automatisch übernommen.

## Demo: Schlechter Commit

```bash
git switch demo/schlechter-commit
git commit -m "update"  # Wird von commit-msg abgelehnt!
```

## Verteilung

### Variante A: Symlinks (wie hier)
```bash
scripts/install-hooks.sh
```

### Variante B: init.templatedir (automatisch bei git init)
```bash
git config --global init.templatedir ~/.git-templates/hooks/
```

### Variante C: core.hooksPath (alle zeigen auf einen Ordner)
```bash
git config core.hooksPath .githooks
```
Damit werden Hooks direkt aus .githooks/ gelesen — kein Symlink nötig!
