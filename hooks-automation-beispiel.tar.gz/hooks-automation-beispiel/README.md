# Git Hooks & Automation — Beispiel-Projekt

Zeigt wie man Git Hooks im Team verwendet und verteilt.
Enthält 5 funktionsfähige Hooks + Installations-Script + Demo-Branch.

## Quickstart

```bash
tar xzf hooks-automation-beispiel.tar.gz
cd hooks-automation-beispiel

# Hooks installieren:
bash scripts/install-hooks.sh

# Oder (noch einfacher):
git config core.hooksPath .githooks
```

---

## Verfügbare Hooks und ihre Aufgaben

Alle Hooks liegen in `.githooks/` und werden automatisch ausgeführt.

### 1. pre-commit (Syntax + Whitespace)

**Wann?** Bevor der Commit erstellt wird (noch abbrechbar!)

**Was macht er?**
1. Prüft auf **nachgestellte Leerzeichen** (trailing whitespace)
2. Validiert **Python-Syntax** aller geänderten `.py`-Dateien

### Ausprobieren:
```bash
# Einen Fehler provozieren (trailing whitespace):
echo "test    " > test.txt
git add .
git commit -m "FEAT: Test-Datei"
# → ❌ Fehler: Nachgestellte Leerzeichen gefunden!
```

### 2. commit-msg (Format-Validierung)

**Wann?** Nachdem die Commit-Nachricht eingegeben wurde

**Was macht er?**
1. Maximal **50 Zeichen** in der ersten Zeile (Betreff)
2. Muss mit einem gültigen **Prefix** beginnen: `FEAT`, `FIX`, `DOCS`, `STYLE`, `REFACTOR`, `TEST`, `CHORE`, `BREAK`
3. Zweite Zeile muss **leer** sein (zwischen Betreff und Body)

### Ausprobieren:
```bash
git commit -m "update"
# → ❌ Betreff muss mit Prefix beginnen!

git commit -m "FEAT: Test-Datei"
# → ✅ Geht durch!

git commit -m "FIX: Dies ist eine sehr lange Commit-Nachricht die ueber 50 Zeichen geht und deswegen abgelehnt wird"
# → ❌ Betreff ist zu lang!
```

### 3. pre-push (Tests + Debug-Guard)

**Wann?** Vor `git push`

**Was macht er?**
1. Führt simulierte Tests aus
2. Warnt vor **Debug-Logs** (`console.log`, `FIXME`, `TODO`, `debugger`)

### Ausprobieren:
```bash
# Auf den Demo-Branch wechseln und pushen:
git switch demo/schlechter-commit
git push origin demo/schlechter-commit
# → ⚠️ Warnung: Debug/Artefakte gefunden!
# Du hast 3 Sekunden zum Abbrechen (Strg+C)
```

### 4. post-commit (Automatischer Changelog)

**Wann?** Nach erfolgreichem Commit

**Was macht er?**
Schreibt den letzten Commit automatisch in `CHANGELOG.md`

### Ausprobieren:
```bash
git commit -m "FEAT: Noch ein Feature"
cat CHANGELOG.md
# → Automatisch erstellt!
```

### 5. post-merge (Dependency-Update)

**Wann?** Nach einem erfolgreichen Merge

**Was macht er?**
Prüft ob `requirements.txt` oder `package.json` geändert wurden
und führt dann `pip install` / `npm install` aus.

---

## Installation und Verteilung im Team

### Variante A: Symlinks (empfohlen — dieses Projekt)

```bash
bash scripts/install-hooks.sh
```

Die Hooks liegen in `.githooks/` (wird **versioniert**!) und werden per Symlink
nach `.git/hooks/` installiert. So werden Updates automatisch übernommen.

### Variante B: core.hooksPath (noch einfacher!)

```bash
git config core.hooksPath .githooks
```

damit liest Git die Hooks **direkt aus `.githooks/`** – kein Symlink nötig!

### Variante C: init.templatedir (automatisch bei git init)

```bash
git config --global init.templatedir ~/.git-templates/hooks/
```

Alle neuen Repos haben dann sofort die Hooks.

---

## Demo: Schlechter Commit

**Branch: demo/schlechter-commit**

Dieser Branch enthält bewusst schlechten Code:
- Whitespace-Fehler
- Debug-Logs (`print("DEBUG...")`)

```bash
git switch demo/schlechter-commit
git commit -m "update"
# → ❌ Erster Hook lehnt ab: commit-msg (kein Prefix!)

git commit -m "BUG: Schlechten Code eingebaut"
# → ✅ Format OK, aber pre-commit prüft Syntax...
# → ggf. Fehler bei Whitespace oder Syntax
# → pre-push warnt vor Debug-Logs
```

Diese Kette zeigt: **Hooks fangen Fehler frühzeitig** — vor dem Push!

---

## Wichtige Regeln für Git Hooks

1. **Hooks sind client-seitig** — jeder Entwickler muss sie selbst installieren
2. **`--no-verify`** (`-n`) umgeht `pre-commit` und `commit-msg` (nicht für pre-push!)
3. **`git push --no-verify`** umgeht pre-push (nur in Ausnahmen!)
4. **Hooks können langsam sein** — nur das Nötigste prüfen
5. **Exit-Code ≠ 0** bricht den Vorgang ab (bei pre-commit, commit-msg, pre-push)
6. **post-commit / post-merge** können nicht abbrechen (laufen immer durch)

---

## Branches Übersicht

```
main ──── demo/schlechter-commit (schlechter Code zum Testen)
```

---

## Dateien in diesem Projekt

| Datei | Zweck |
|-------|-------|
| `.githooks/pre-commit` | Syntax + Whitespace-Prüfung |
| `.githooks/commit-msg` | Commit-Nachrichten-Format |
| `.githooks/pre-push` | Tests + Debug-Guard |
| `.githooks/post-commit` | Automatischer Changelog |
| `.githooks/post-merge` | Dependency-Update |
| `scripts/install-hooks.sh` | Installiert alle Hooks per Symlink |
