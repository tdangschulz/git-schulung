#!/bin/bash
# Installiert Team-Hooks in .git/hooks/
# Symlink, damit Updates automatisch übernommen werden
HOOKS_DIR="$(git rev-parse --show-toplevel)/.githooks"
TARGET_DIR="$(git rev-parse --show-toplevel)/.git/hooks"

echo "Installiere Git Hooks..."
for hook in "$HOOKS_DIR"/*; do
    name=$(basename "$hook")
    ln -sf "../../.githooks/$name" "$TARGET_DIR/$name"
    echo "  ✅ $name → $TARGET_DIR/$name"
done
echo "Fertig! Hooks sind aktiv. 🚀"
