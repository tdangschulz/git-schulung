#!/usr/bin/env python3
def greet(name):
    return f"Hallo, {name}!"

def add(a, b):
    return a + b

if __name__ == "__main__":
    print(greet("Welt"))
    print(add(3, 4))

# Schlechter Code — Hook wird das ablehnen
def broken_function(  x  ):
  return    x + 1

print("DEBUG: Das ist ein Test")
